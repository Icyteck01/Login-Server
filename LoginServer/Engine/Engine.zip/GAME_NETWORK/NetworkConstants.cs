﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.Scripts.Network.SoketIONetwork.Communication
{
    public class NetworkConstants
    {
        public const short GS_HANDSHAKE = 0;
        public const short GS_PING = 1;
        public const short GS_STATUSCHANGE = 2;
        public const short GS_USERDOMAIN = 3;
        public const short DE_USERDOMAIN = 4;

        public const short CMD_HEARTBEAT = 1022;
        public const short CMD_LOGIN = 1000;
        public const short CMD_EXIT_CHARSELECTION = 1010;
        public const short CMD_CREATE_PLAYER = 1012;
        public const short CMD_DEL_PLAYER = 1013;
        public const short CMD_CLIENT_READY_STATE = 1027;
        public const short CMD_CLIENT_REQUEST_ENTER_LOBY = 1028;
        public const short CMD_DISPLAY_COUNTDOWN = 1029;
        public const short CMD_LOGOUT = 1011;
        public const short CMD_KICK = 10000;


    }
}
