﻿using DRNetworkProtocol;
using MsgPack.Serialization;
using System.IO;

namespace Assets.Engine.Network.Models.Iner
{
    public class I_MatchResults : DRMessage
    {
        public int winTeam = 0;
        public byte[] data = new byte[0];

        public override void Deserialize(DRReader reader)
        {
            winTeam = reader.ReadInt32();
            data = (byte[])reader.ReadBytesAndSize();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write(winTeam);
            writer.WriteBytesFull(data);
        }

        public I_MatchParticipant[] getPlayers()
        {
            using (var memStream = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<I_MatchParticipant[]>();
                byte[] x = data;
                memStream.Write(x, 0, x.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = serializer.Unpack(memStream);
                return obj;
            }
        }

        public void writeShips(I_MatchParticipant[] obj)
        {
            using (var ms = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<I_MatchParticipant[]>();
                serializer.Pack(ms, obj);
                data = ms.ToArray();
            }
        }
    }
}
