﻿using DRNetworkProtocol;

namespace Assets.Scripts.Network.SoketIONetwork.Communication.Packets
{
    public class STATUSCHANGE : DRMessage
    {
        public int mapId = 1;
        public int status = 1;
        public override void Deserialize(DRReader reader)
        {
            status = reader.ReadInt32();
            mapId = reader.ReadInt32();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write(status);
            writer.Write(mapId);
        }
    }
}
