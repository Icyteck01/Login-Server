﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.Engine.Network.Models.Iner
{
    [Serializable]
    public class I_MatchParticipant
    {
        public int playerId;
        public int kills;
        public int deaths;
        public int totalDamage;
        public int beaconsCaptured;
        public int reward;
        public int rank;
        public int team;
    }
}
