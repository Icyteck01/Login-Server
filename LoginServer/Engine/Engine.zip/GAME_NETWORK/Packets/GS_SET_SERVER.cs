﻿namespace DRNetworkProtocol
{
    public class GS_SET_SERVER : DRMessage
    {
        public short status = 0;
        public short gsState = 0;
        public int portNo = 0;
        public string ip = "127.0.0.1";
        public override void Deserialize(DRReader reader)
        {
            status = reader.ReadInt16();
            gsState = reader.ReadInt16();
            portNo = reader.ReadInt32();
            ip = reader.ReadString();
        }
        public override void Serialize(DRWriter writer)
        {
            writer.Write(status);
            writer.Write(gsState);
            writer.Write(portNo);
            writer.Write(ip);
        }
    }
}
