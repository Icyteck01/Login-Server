﻿using DRNetworkProtocol;

namespace GateWayServer.InterServerCommunication.Packets
{
    public class HandShake : DRMessage
    {
        public int id;
        public int mapId;
        public int status;
        public string ip;
        public int port;

        public override void Deserialize(DRReader reader)
        {
            id = reader.ReadInt32();
            mapId = reader.ReadInt32();
            status = reader.ReadInt32();
            ip = reader.ReadString();
            port = reader.ReadInt32();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write(id);
            writer.Write(mapId);
            writer.Write(status);
            writer.Write(ip);
            writer.Write(port);
        }
    }
}
