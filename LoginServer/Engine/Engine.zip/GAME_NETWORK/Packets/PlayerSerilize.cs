﻿using System;
using Assets.Database.Models;
using System.IO;
using MsgPack.Serialization;

namespace Assets.NetworkPackets.Models
{
    [Serializable]
    public class PlayerSerilize
    {
        public byte[] data;
        public short Level;
        public int PlayerId;
        public short exp;
        public short SkinId;
        public int UserId;
        public short GameType;
        public string PlayerName;

        public WeaponSocket[] GetWeapons()
        {
            using (var memStream = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<WeaponSocket[]>();
                byte[] x = data;
                memStream.Write(x, 0, x.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = serializer.Unpack(memStream);
                return obj;
            }
        }

        public void SetWeapons(WeaponSocket[] obj)
        {
            using (var ms = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<WeaponSocket[]>();
                serializer.Pack(ms, obj);
                data = ms.ToArray();
            }
        }
    }
}
