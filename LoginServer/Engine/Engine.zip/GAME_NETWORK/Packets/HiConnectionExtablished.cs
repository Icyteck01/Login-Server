﻿using DRNetworkProtocol;

namespace Assets.Scripts.Network.SoketIONetwork.Communication.Packets
{
    public class HiConnectionExtablished : DRMessage
    {
        public int mapId;
        public string ip;
        public int port;
        public string password;
        public int cat;
        public override void Deserialize(DRReader reader)
        {
            mapId = reader.ReadInt32();
            ip = reader.ReadString();
            port = reader.ReadInt32();
            password = reader.ReadString();
            cat = reader.ReadInt32();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write(mapId);
            writer.Write(ip);
            writer.Write(port);
            writer.Write(password);
            writer.Write(cat);
        }
    }
}
