﻿using MsgPack.Serialization;
using System.IO;
using DRNetworkProtocol;

namespace Assets.NetworkPackets.Models
{
    public class InterPayLoad : DRMessage
    {
        public int lobyId;
        public byte[] data = new byte[0];

        public override void Deserialize(DRReader reader)
        {
            lobyId = reader.ReadInt32();
            data = (byte[])reader.ReadBytesAndSize();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write(lobyId);
            writer.WriteBytesFull(data);
        }

        public PlayerSerilize[] getShips()
        {
            using (var memStream = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<PlayerSerilize[]>();
                byte[] x = data;
                memStream.Write(x, 0, x.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = serializer.Unpack(memStream);
                return obj;
            }
        }

        public void writeShips(PlayerSerilize[] obj)
        {
            using (var ms = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<PlayerSerilize[]>();
                serializer.Pack(ms, obj);
                data = ms.ToArray();
            }
        }
    }
}
