﻿using DRNetworkProtocol;
using System.Collections.Generic;

namespace Assets.Scripts.Network.SoketIONetwork.Communication.Packets
{
    public class ConfirmPacket : DRMessage
    {
        public int lobyId = 0;
        public int state = 0;
        public int[] value;

        public override void Deserialize(DRReader reader)
        {
            List<int> arr = new List<int>();
            int read = reader.ReadInt16();
            for (int i = 0; i < read; i++)
                arr.Add(reader.ReadInt32());

            lobyId = reader.ReadInt32();
            state = reader.ReadInt32();
            value = arr.ToArray();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write((short)value.Length);
            for (int i = 0; i < value.Length; i++)
                writer.Write(value[i]);
            writer.Write(lobyId);
            writer.Write(state);
        }
    }
}
