﻿using DRNetworkProtocol;

namespace Assets.Scripts.Network.SoketIONetwork.Communication.Packets
{
    public class GSPING : DRMessage
    {
        public int value = 1;
        public override void Deserialize(DRReader reader)
        {
            value = reader.ReadInt32();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write(value);
        }
    }
}
