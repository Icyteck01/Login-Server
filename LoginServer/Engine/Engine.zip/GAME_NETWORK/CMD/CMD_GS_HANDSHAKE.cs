﻿using System;
using DRNetworkProtocol;
using Assets.Scripts.Network.SoketIONetwork.Communication.Packets;
using LoginServer.Database;
using Assets.Scripts.Network.SoketIONetwork.Communication;
using GateWayServer.InterServerCommunication.Packets;
using GateWayServer.Engine.Database.Models;
using GateWayServer.Engine.Database.Managers;

namespace LoginServer.Engine.GAME_NETWORK.CMD
{
    public class CMD_GS_HANDSHAKE : DRPacketInterface
    {
        public void Execute(DRPacket netMsg)
        {
            try
            {
                HiConnectionExtablished xd = netMsg.reader.ReadMessage<HiConnectionExtablished>();
                if (xd != null)
                {
                    if (xd.password.Equals(NetworkServer.Instance.BINDPASSWORD))
                    {
                        HandShake hs = new HandShake();
                        GameServerPort server = ServersManager.Instance.getNextFreePort(netMsg.player.connectionId);
                        hs.id = server.ConnectionId;
                        hs.port = server.Port;
                        if(NetworkServer.HOSTLOCATIONS_IP.ContainsKey(xd.cat))
                        {
                            hs.ip = NetworkServer.HOSTLOCATIONS_IP[xd.cat];
                        }
                        else
                        {
                            hs.ip = "0.0.0.0";
                        }
                        hs.status = (int)STATE.STOPED;
                        hs.mapId = xd.mapId;
                        ServersManager.Instance.updateGS(server.ConnectionId, hs);
                        netMsg.player.isServer = true;
                        netMsg.player.Send(NetworkConstants.GS_HANDSHAKE, hs);

                    }
                }
            }
            catch { }
        }
    }
}
