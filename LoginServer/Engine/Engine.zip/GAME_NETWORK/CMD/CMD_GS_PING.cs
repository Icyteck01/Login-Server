﻿using Assets.Scripts.Network.SoketIONetwork.Communication.Packets;
using DRNetworkProtocol;
using LoginServer.Database;
using System;

namespace LoginServer.Engine.GAME_NETWORK.CMD
{
    public class CMD_GS_PING : DRPacketInterface
    {
        public void Execute(DRPacket netMsg)
        {
            GSPING gsp = netMsg.reader.ReadMessage<GSPING>();
            if(gsp != null)            
                ServersManager.Instance.updateTimeStamp(netMsg.player.connectionId);
        }
    }
}
