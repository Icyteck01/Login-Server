﻿using Assets.Scripts.Network.SoketIONetwork.Communication.Packets;
using DRNetworkProtocol;
using LoginServer.Engine.Managers;

namespace LoginServer.Engine.GAME_NETWORK.CMD
{
    public class GS_USERDOMAIN : DRPacketInterface
    {
        public LobyManager lobyManager = null;
        public void Execute(DRPacket netMsg)
        {
            ConfirmPacket packet = netMsg.reader.ReadMessage<ConfirmPacket>();
            if(packet != null)
            {
                if (lobyManager == null)
                    lobyManager = LobyManager.Instance;

                lobyManager.ConectPlayers(packet.value, packet.state, packet.lobyId, netMsg.player.connectionId);
            }
        }
    }
}
