﻿using System;
using DRNetworkProtocol;
using LoginServer.Database;
using Assets.Scripts.Network.SoketIONetwork.Communication.Packets;

namespace LoginServer.Engine.GAME_NETWORK.CMD
{
    public class CMD_GS_STATUSCHANGE : DRPacketInterface
    {
        public void Execute(DRPacket netMsg)
        {
            STATUSCHANGE stc = netMsg.reader.ReadMessage<STATUSCHANGE>();
            if (stc != null)
            {
                ServersManager.Instance.UpdateStatus(netMsg.player.connectionId, stc.mapId, stc.status);
                LogParser.Info(string.Format("ONStatusUpdate:[{0}] SID[{1}] STATUS[{1}]", netMsg.player.connectionId, stc.mapId, stc.status));
            }
        }
    }
}
