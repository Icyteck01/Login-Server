﻿using JHUI.Utils;
using LoginServer.Database;

namespace DRNetworkProtocol
{
    public class CMD_EXIT_CHARSELECTION : DRPacketInterface
    {
        public short id = 0;
        private AccountManager userManager;
        private GameConfigsManager gdb;

        public short getID()
        {
            return this.id;
        }

        public void setId(short paramInt)
        {
            this.id = paramInt;
        }

        public CMD_EXIT_CHARSELECTION()
        {
            this.userManager = AccountManager.Instance;
            this.gdb = GameConfigsManager.Instance;
        }

        public void Execute(DRPacket netMsg)
        {
            int connectionId = netMsg.player.connectionId;
            AccountOBJ onlineById = this.userManager.getOnlineById(connectionId);
            if (onlineById == null)
                return;
            M_StandardResponse standardResponse1 = netMsg.reader.ReadMessage<M_StandardResponse>();
            M_StandardResponse standardResponse2 = new M_StandardResponse();
            standardResponse2.response = standardResponse1.response;
            standardResponse2.code = 0;
            standardResponse2.module = 1010;
            onlineById.logoutTime = Time.timeStampMilisecond;
            this.userManager.saveEntity(onlineById);
            this.userManager.removeOnline(connectionId, onlineById);
            NetworkServer.Instance.SendToClient(connectionId, 1010, standardResponse2, true);
        }

        public void Dispose()
        {
            this.userManager = null;
            this.gdb = null;
        }
    }
}
