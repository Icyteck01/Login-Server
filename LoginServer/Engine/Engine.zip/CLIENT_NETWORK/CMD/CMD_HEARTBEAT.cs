﻿using System;

namespace DRNetworkProtocol
{
  public class CMD_HEARTBEAT : DRPacketInterface
  {
    public void Dispose()
    {
    }

    public void Execute(DRPacket netMsg)
    {
      throw new NotImplementedException();
    }
  }
}
