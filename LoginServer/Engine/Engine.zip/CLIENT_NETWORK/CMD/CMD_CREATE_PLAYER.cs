﻿using Assets.NetworkPackets;
using Assets.Scripts.Models;
using LoginServer.Database;
using LoginServer.MYSQL.Tables;
using System;
using System.Collections.Generic;

namespace DRNetworkProtocol
{
    public class CMD_CREATE_PLAYER : DRPacketInterface
    {
        public short id = 0;
        private AccountManager userManager;
        private GameConfigsManager gdb;
        private MysqlManager mysqlManager;

        public short getID()
        {
            return this.id;
        }

        public void setId(short paramInt)
        {
            this.id = paramInt;
        }

        public CMD_CREATE_PLAYER()
        {
            this.userManager = AccountManager.Instance;
            this.gdb = GameConfigsManager.Instance;
            this.mysqlManager = MysqlManager.Instance;
        }

        public void Execute(DRPacket netMsg)
        {
            int connectionId = netMsg.player.connectionId;
            if (!this.userManager.isOnline(connectionId))
                return;
            CreatePlayerInfo createPlayerInfo = netMsg.reader.ReadMessage<CreatePlayerInfo>();
            M_PlayerLoginWithCharacters loginWithCharacters = new M_PlayerLoginWithCharacters();
            loginWithCharacters.time = DateTime.Now.ToBinary();
            AccountOBJ onlineById = this.userManager.getOnlineById(connectionId);
            if (onlineById == null)
            {
                loginWithCharacters.response = 1;
                loginWithCharacters.code = 2;
                NetworkServer.Instance.SendToClient(connectionId, 1012, loginWithCharacters, true);
            }
            else
            {
                ShipConfig shipModelById = this.gdb.getShipModelById(createPlayerInfo.shipId);
                if (shipModelById == null)
                {
                    loginWithCharacters.response = 1;
                    loginWithCharacters.code = 4;
                    NetworkServer.Instance.SendToClient(connectionId, 1012, loginWithCharacters, true);
                }
                else
                {
                    int price = shipModelById.Price;
                    int gold = onlineById.gold;
                    if (price > gold)
                    {
                        loginWithCharacters.response = 1;
                        loginWithCharacters.code = 5;
                        NetworkServer.Instance.SendToClient(connectionId, 1012, loginWithCharacters, true);
                    }
                    else
                    {
                        Characters character0 = new Characters(onlineById.id, createPlayerInfo.shipId, "TEST");
                        CharacterOBJ character1 = new CharacterOBJ(character0, true);
                        character1.connectionID = connectionId;
                        onlineById.gold = onlineById.gold - price;
                        onlineById.characters.Add(character1.playerId, character1);
                        onlineById.isSendGameServer = false;
                        onlineById.connectionID = netMsg.player.connectionId;
                        onlineById.isOnline = true;
                        onlineById.lastKnownIp = onlineById.ip;
                        onlineById.ip = netMsg.player.address;
                        loginWithCharacters.response = 0;
                        loginWithCharacters.gstoken = onlineById.id;
                        loginWithCharacters.conId = connectionId;
                        Dictionary<int, ShipInfo> dictionary = new Dictionary<int, ShipInfo>();
                        int index = 0;
                        foreach (CharacterOBJ character2 in onlineById.characters.Values)
                        {
                            dictionary[index] = new ShipInfo()
                            {
                                PlayerId = character2.playerId,
                                skinId = (short)character2.skinId,
                                Level = (short)character2.level,
                                exp = character2.exp,
                            };
                            ++index;
                        }
                        loginWithCharacters.writeInfo(dictionary);
                        loginWithCharacters.credit = onlineById.gold;
                        NetworkServer.Instance.SendToClient(connectionId, 1012, loginWithCharacters, true);
                    }
                }
            }
        }

        public void Dispose()
        {
            this.userManager = null;
            this.gdb = null;
        }
    }
}
