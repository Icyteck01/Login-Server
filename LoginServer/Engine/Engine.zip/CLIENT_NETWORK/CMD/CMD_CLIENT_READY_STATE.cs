﻿using Assets.Scripts.Network.SoketIONetwork.Communication;
using JHSNetProtocol;
using LoginServer.Database;
using LoginServer.Engine.Managers;

namespace DRNetworkProtocol
{
    public class CMD_CLIENT_READY_STATE : IJHSInterface
    {
        private AccountManager pdbt;
        private LobyManager lobyManager;

        public void Dispose()
        {
            this.pdbt = null;
            this.lobyManager = null;
        }

        public bool Execute(JHSNetworkMessage netMsg)
        {
            ONE_CODE_PACKET msg = netMsg.ReadMessage<ONE_CODE_PACKET>();
            if (msg != null)
            {
                uint connectionId = netMsg.conn.connectionId;
                if (this.pdbt == null)
                    this.pdbt = AccountManager.Instance;
                if (this.lobyManager == null)
                    this.lobyManager = LobyManager.Instance;
                AccountOBJ account = this.pdbt.getOnlineById(connectionId);
                if (account != null)
                {
                    //0 = Search match
                    //1 = Cancel Search
                    //3 = Disconnect
                    switch(msg.code)
                    {
                        case 0:
                            CharacterOBJ chrobj = account.getPlayer(msg.roleid);
                            if(chrobj != null)
                                chrobj.connectionID = connectionId;

                            if (!account.IsInQueue && this.lobyManager.AddPlayerToQueue(chrobj, 0))
                            {
                                account.IsInQueue = true;
                                netMsg.conn.Send(NetworkConstants.CMD_CLIENT_READY_STATE, new ONE_CODE_PACKET(1));
                            }
                            else
                            {
                                account.IsInQueue = false;
                                netMsg.conn.Send(NetworkConstants.CMD_CLIENT_READY_STATE, new ONE_CODE_PACKET(0));
                            }
                            break;
                        case 1:
                            if (this.lobyManager.DelPlayerFromQueue(account.id))
                            {
                                account.IsInQueue = false;
                                netMsg.conn.Send(NetworkConstants.CMD_CLIENT_READY_STATE, new ONE_CODE_PACKET(3));
                            }
                            else
                            {
                                account.IsInQueue = false;
                                netMsg.conn.Send(NetworkConstants.CMD_CLIENT_READY_STATE, new ONE_CODE_PACKET(4));
                            }
                            break;
                    }


                }
                else
                    netMsg.conn.Send((short)10000, new M_StandardResponse(){code = (short)2});
            }
            else
                netMsg.conn.Send((short)10000, new M_StandardResponse() { code = (short)2 });

            return true;
        }
    }
}
