﻿using Assets.NetworkPackets;
using Assets.Scripts.Network.SoketIONetwork.Communication;
using Assets.Util;
using JHUI.Utils;
using LoginServer.Database;
using System;
using System.Collections.Generic;

namespace DRNetworkProtocol
{
    public class CMD_LOGIN : DRPacketInterface
    {
        public short id = 0;
        public AccountManager userManager = (AccountManager)null;

        public short getID()
        {
            return this.id;
        }

        public void setId(short paramInt)
        {
            this.id = paramInt;
        }

        public void Execute(DRPacket netMsg)
        {
            if (this.userManager == null)
                this.userManager = AccountManager.Instance;
            int connectionId1 = netMsg.player.connectionId;
            Login login = netMsg.reader.ReadMessage<Login>();
            if(login == null)
            {
                M_StandardResponse sr = new M_StandardResponse();
                sr.code = (short)ErrorCodes.VERSION_INVALID;
                NetworkServer.Instance.SendToClient(connectionId1, NetworkConstants.CMD_KICK, sr, true);
                return;
            }
            if(login.version != NetworkServer.GAMEVERSION)
            {
                M_StandardResponse sr = new M_StandardResponse();
                sr.code = (short)ErrorCodes.VERSION_INVALID;
                NetworkServer.Instance.SendToClient(connectionId1, NetworkConstants.CMD_KICK, sr, true);
                return;
            }
            AccountOBJ accountByUserName = this.userManager.getAccountByUserName(StringUtils.validPlayerName(login.user) ? login.user : "");
            M_PlayerLoginWithCharacters loginWithCharacters = new M_PlayerLoginWithCharacters();
            if (accountByUserName == null)
            {
                loginWithCharacters.response = 1;
                loginWithCharacters.code = (short)ErrorCodes.INCORRECT_ACCOUNT;
                NetworkServer.Instance.SendToClient(connectionId1, NetworkConstants.CMD_LOGIN, loginWithCharacters, true);
                LogParser.Info("LoginHandler:: No user found:" + login.user);
            }
            else if (!accountByUserName.password.Trim().Equals(login.pass.Trim()))
            {
                loginWithCharacters.response = 1;
                loginWithCharacters.code = (short)ErrorCodes.INCORRECT_PASSWORD;
                NetworkServer.Instance.SendToClient(connectionId1, NetworkConstants.CMD_LOGIN, loginWithCharacters, true);
                LogParser.Info("LoginHandler:: Incorrect Password for account:" + login.user);
            }
            else
            {
                string username = accountByUserName.username;
                string password = accountByUserName.password;
                int connectionId2 = accountByUserName.connectionID;
                AccountOBJ onlineByUserName = this.userManager.getAccountOnlineByUserName(accountByUserName.username);
                if (onlineByUserName != null)
                {
                    M_StandardResponse sr = new M_StandardResponse();
                    sr.code = (short)ErrorCodes.PLAYER_EXISTS;
                    NetworkServer.Instance.SendToClient(connectionId1, NetworkConstants.CMD_KICK, sr, true);
                    NetworkServer.Instance.RemoveOnline(onlineByUserName.connectionID);
                    this.userManager.removeOnline(onlineByUserName.connectionID, onlineByUserName);
                }
                loginWithCharacters.time = DateTime.Now.ToBinary();
                accountByUserName.isSendGameServer = false;
                accountByUserName.connectionID = netMsg.player.connectionId;
                accountByUserName.isOnline = true;
                accountByUserName.lastKnownIp = accountByUserName.ip;
                accountByUserName.ip = netMsg.player.address;
                accountByUserName.loginTime = Time.timeStampMilisecond;
                loginWithCharacters.response = 0;
                loginWithCharacters.gstoken = accountByUserName.id;
                loginWithCharacters.conId = connectionId1;
                netMsg.player.isCanConnectToUdp = true;
                Dictionary<int, ShipInfo> dictionary = new Dictionary<int, ShipInfo>();
                int index = 0;
                foreach (CharacterOBJ character in accountByUserName.characters.Values)
                {
                    dictionary[index] = new ShipInfo()
                    {
                        PlayerId = character.playerId,
                        exp = (int)character.exp,
                        skinId = (short)character.skinId,
                        Level = (short)character.level
                    };
                    ++index;
                }
                loginWithCharacters.code = !login.isRecoonect ? login.screen : login.screen;
                loginWithCharacters.writeInfo(dictionary);
                loginWithCharacters.credit = accountByUserName.gold;
                loginWithCharacters.credit1 = accountByUserName.silver;

                this.userManager.registerOnline(connectionId1, accountByUserName);
                NetworkServer.Instance.SendToClient(connectionId1, 1000, loginWithCharacters, true);
                LogParser.Info("LoginHandler:: User Logged in Successfully:[" + accountByUserName.username + "] Connection ID:[" + connectionId1 + "]");
            }
        }

        public void Dispose()
        {
        }
    }
}
