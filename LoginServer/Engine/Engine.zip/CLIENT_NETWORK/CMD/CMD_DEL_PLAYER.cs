﻿using LoginServer.Database;

namespace DRNetworkProtocol
{
    public class CMD_DEL_PLAYER : DRPacketInterface
  {
    public short id = 0;
    private AccountManager pdbt;

    public short getID()
    {
      return this.id;
    }

    public void setId(short paramInt)
    {
      this.id = paramInt;
    }

    public CMD_DEL_PLAYER()
    {
      this.pdbt = AccountManager.Instance;
    }

    public void Execute(DRPacket netMsg)
    {
      if (!this.pdbt.isOnline(netMsg.player.connectionId))
        return;
      netMsg.reader.ReadMessage<CreatePlayerInfo>();
    }

    public void Dispose()
    {
      this.pdbt = (AccountManager) null;
    }
  }
}
