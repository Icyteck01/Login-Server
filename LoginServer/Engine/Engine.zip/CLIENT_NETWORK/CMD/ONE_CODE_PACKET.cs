﻿using JHSNetProtocol;

namespace DRNetworkProtocol
{
    public class ONE_CODE_PACKET : JHSMessageBase
    {
        public short code = 0;
        public int roleid = 0;
        public ONE_CODE_PACKET()
        {

        }

        public ONE_CODE_PACKET(short _code, int _roleid = 0)
        {
            code = _code;
            roleid = _roleid;
        }

        public override void Serialize(JHSNetworkWriter writer)
        {
            writer.Write((short)code);
            writer.Write((int)roleid);
        }
        public override void Deserialize(JHSNetworkReader reader)
        {
            code = reader.ReadInt16();
            roleid = reader.ReadInt32();
        }
    }
}
