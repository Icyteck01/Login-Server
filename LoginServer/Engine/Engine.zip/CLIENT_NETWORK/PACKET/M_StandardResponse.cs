﻿using JHSNetProtocol;

namespace DRNetworkProtocol
{
    public class M_StandardResponse : JHSMessageBase
    {
        public short response = (short)ErrorCodes.ERROR;
        public short code = 0;
        public short module = 0;

        public override void Deserialize(JHSNetworkReader reader)
        {
            module = reader.ReadInt16();
            code = reader.ReadInt16();
            response = reader.ReadInt16();
        }
        public override void Serialize(JHSNetworkWriter writer)
        {
            writer.Write(module);
            writer.Write(code);
            writer.Write(response);
        }
    }
}
