﻿using Assets.NetworkPackets;
using MsgPack.Serialization;
using System;
using System.Collections.Generic;
using System.IO;

namespace DRNetworkProtocol
{
    public class M_PlayerLoginWithCharacters : DRMessage
    {
        public int response = (int)ErrorCodes.ERROR;
        public string playerName;
        public int code = 0;
        public byte[] players = new byte[0];
        public byte[] weaponsInInventory = new byte[0];
        public long time;
        public int credit;
        public int credit1;
        public int gstoken;
        public int conId;
        public short iconId = 0;

        public override void Deserialize(DRReader reader)
        {
            conId = reader.ReadInt32();
            playerName = reader.ReadString();
            response = reader.ReadInt32();
            code = reader.ReadInt32();
            players = (byte[])reader.ReadBytesAndSize();
            weaponsInInventory = (byte[])reader.ReadBytesAndSize();
            time = reader.ReadInt64();
            credit = reader.ReadInt32();
            credit1 = reader.ReadInt32();
            gstoken = reader.ReadInt32();
            iconId = reader.ReadInt16();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.Write((Int32)conId);
            writer.Write(playerName);
            writer.Write((Int32)response);
            writer.Write((Int32)code);
            writer.WriteBytesFull(players);
            writer.WriteBytesFull(weaponsInInventory);
            writer.Write((Int64)time);
            writer.Write((Int32)credit);
            writer.Write((Int32)credit1);
            writer.Write(gstoken);
            writer.Write(iconId);
        }

        public void writeInfo(Dictionary<int, ShipInfo> obj)
        {
            using (var ms = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<Dictionary<int, ShipInfo>>();
                serializer.Pack(ms, obj);
                players = ms.ToArray();
            }
        }

        public void WriteWeapons(InventoryWeapon[] obj)
        {
            using (var ms = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<InventoryWeapon[]>();
                serializer.Pack(ms, obj);
                weaponsInInventory = ms.ToArray();
            }
        }

        public InventoryWeapon[] ReadWeapons()
        {
            using (var memStream = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<InventoryWeapon[]>();
                byte[] x = weaponsInInventory;
                memStream.Write(x, 0, x.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = serializer.Unpack(memStream);
                return obj;
            }
        }

        public Dictionary<int, ShipInfo> readShips()
        {
            using (var memStream = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<Dictionary<int, ShipInfo>>();
                byte[] x = players;
                memStream.Write(x, 0, x.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = serializer.Unpack(memStream);
                return obj;
            }
        }

    }
}
