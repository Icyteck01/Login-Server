﻿using System;

namespace DRNetworkProtocol
{
    public class Login : DRMessage
    {
        public string user = "";
        public string pass = "";
        public bool isRecoonect = false;
        public int screen = 0;
        public int version = 0;

        // This method would be generated
        public override void Deserialize(DRReader reader)
        {
            user = reader.ReadString();
            pass = reader.ReadString();
            isRecoonect = reader.ReadBoolean();
            screen = reader.ReadInt32();
            version = reader.ReadInt32();
        }

        // This method would be generated
        public override void Serialize(DRWriter writer)
        {
            writer.Write(user);
            writer.Write(pass);
            writer.Write(isRecoonect);
            writer.Write((Int32)screen);
            writer.Write((Int32)version);
        }
    }
}
