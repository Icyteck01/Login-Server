﻿using MsgPack.Serialization;
using System.IO;

namespace DRNetworkProtocol
{
    public class MapListPacket : DRMessage
    {
        public byte[] _maps;
        public MapsList[] maps {
            get
            {
                return read();
            }
            set
            {
                write(value);
            }
        }

        public override void Deserialize(DRReader reader)
        {
            _maps = (byte[])reader.ReadBytesAndSize();
        }

        public override void Serialize(DRWriter writer)
        {
            writer.WriteBytesFull(_maps);
        }
        public void write(MapsList[] obj)
        {
            using (var ms = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<MapsList[]>();
                serializer.Pack(ms, obj);
                _maps = ms.ToArray();
            }
        }

        public MapsList[] read()
        {
            using (var memStream = new MemoryStream())
            {
                var serializer = SerializationContext.Default.GetSerializer<MapsList[]>();
                byte[] x = _maps;
                memStream.Write(x, 0, x.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = serializer.Unpack(memStream);
                return obj;
            }
        }
    }
}
