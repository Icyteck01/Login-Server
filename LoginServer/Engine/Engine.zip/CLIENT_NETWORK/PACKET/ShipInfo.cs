﻿using Assets.Database.Models;
using System;
using System.Collections.Generic;

namespace Assets.NetworkPackets
{
    [Serializable]
    public class ShipInfo
    {
        public int PlayerId;
        public int exp;
        public short Level;
        public short skinId;
        public WeaponSocket[] weapons;
    }
}
