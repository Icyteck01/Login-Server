﻿namespace DRNetworkProtocol
{
    public class CreatePlayerInfo : DRMessage
    {
        public int shipId;
        // This method would be generated
        public override void Deserialize(DRReader reader)
        {
            shipId = reader.ReadInt32();
        }

        // This method would be generated
        public override void Serialize(DRWriter writer)
        {
            writer.Write(shipId);
        }
    }
}
