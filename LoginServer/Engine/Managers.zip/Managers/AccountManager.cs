﻿using DRNetworkProtocol;
using JHUI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LoginServer.Database
{
    public sealed class AccountManager : JBehavor
    {
        private static readonly AccountManager instance = new AccountManager();
        public static AccountManager Instance
        {
            get
            {
                return instance;
            }
        }
        private Dictionary<int, AccountOBJ> online = new Dictionary<int, AccountOBJ>();
        private MysqlManager sqlManager;
        private ServersManager serversManager;

        private AccountManager()
        {
            this.sqlManager = MysqlManager.Instance;
            this.serversManager = ServersManager.Instance;
        }

        public int TotalPlayersOnline()
        {
            return this.online.Count;
        }

        public int TotalAccounts()
        {
            return this.sqlManager.Count();
        }

        public AccountOBJ GetAccountFromDbByUserName(string username)
        {
            return this.sqlManager.GetAccountFromDbByUserName(username);
        }


        public bool isOnline(int connectionId)
        {
            return this.online.ContainsKey(connectionId);
        }

        public bool isOnline(string username)
        {
            return getAccountOnlineByUserName(username) != null;
        }

        public void registerOnline(int connectionId, AccountOBJ account)
        {
            if (this.online.ContainsKey(connectionId))
                return;
            this.online[connectionId] = account;
        }

        public AccountOBJ getAccountOnlineByUserId(int userId)
        {
            return this.online.FirstOrDefault(x => x.Value.id == userId).Value;
        }

        public AccountOBJ getAccountOnlineByUserName(string username)
        {
            return this.online.FirstOrDefault(x => x.Value.username == username).Value;
        }

        public AccountOBJ getOnlineById(int playerId)
        {
            if (this.online.ContainsKey(playerId))
                return this.online[playerId];
            return null;
        }

        public AccountOBJ getAccountByUserName(string userName)
        {
            return this.GetAccountFromDbByUserName(userName);
        }

        public void saveEntity(DbEntity acc)
        {
            this.sqlManager.saveEntity(acc);
        }

        public void addEntity(DbEntity acc)
        {
            this.sqlManager.addEntity(acc);
        }

        public void removeOnline(int connectionId, AccountOBJ user)
        {
            if (this.online.ContainsKey(connectionId))
                this.online.Remove(connectionId);
            LogParser.Info("LoginHandler:: User Logged out Successfully:[" + user.username + "] Connection ID:[" + (object)connectionId + "]");
        }
    }
}
