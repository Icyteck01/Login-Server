﻿using LoginServer.IDB;
using LoginServer.MYSQL.Tables;
using NHibernate;
using System.Collections.Generic;
using System.Linq;

namespace LoginServer.Database
{
    public sealed class MysqlManager
    {
        public static MysqlManager Instance { get; } = new MysqlManager();
        public DBSession session = null;
        public GameConfigsManager gameConfigsManager = null;
        private MysqlManager()
        {

        }
        public List<Server> getServers()
        {
            return new List<Server>();
        }

        public AccountOBJ GetAccountFromDbByUserName(string username)
        {
            if(session == null)
                session = DBSession.Instance;
            if (gameConfigsManager == null)
                gameConfigsManager = GameConfigsManager.Instance;

            session.CHeck();
            AccountOBJ account = null;
            Users usr = session.session.QueryOver<Users>().Where(x => x.username == username).List().FirstOrDefault();
            if(usr != null)
            {
                account = new AccountOBJ();
                account.id = usr.id;
                account.username = usr.username;
                account.password = usr.password;
                account.priviledgeType = usr.priviledgeType;
                account.email = usr.email;
                account.gold = usr.gold;
                account.silver = usr.silver;
                account.lastKnownIp = usr.lastKnownIp;
                account.loginTime = usr.loginTime;
                account.logoutTime = usr.logoutTime;
                account.createTime = usr.createTime;
                account.characters = new SortedList<int, CharacterOBJ>();
                IList<Characters> chars = session.session.QueryOver<Characters>().Where(x => x.userId == account.id).List();
                for(int c = 0; c < chars.Count; c++)
                {
                    Characters character = chars[c];
                    CharacterOBJ objchar = new CharacterOBJ(character);
                    account.characters.Add(objchar.playerId, objchar);
                }
                if(chars.Count == 0)
                {
                    //create default role
                    using (ITransaction transaction = session.session.BeginTransaction())
                    {
                        Characters ccc = new Characters(account.id, 0, "Random");
                        session.session.Save(ccc); // <-- this
                        transaction.Commit();
                    }
                    chars = session.session.QueryOver<Characters>().Where(x => x.userId == account.id).List();
                    for (int c = 0; c < chars.Count; c++)
                    {
                        Characters character = chars[c];
                        CharacterOBJ objchar = new CharacterOBJ(character);

                        account.characters.Add(objchar.playerId, objchar);
                    }
                }
            }
            return account;
        }

        public int Count()
        {
            return 0;
        }

        public void saveEntity(DbEntity acc)
        {
            if(acc is AccountOBJ)
            {
                AccountOBJ acount = (AccountOBJ)acc;
                Users usr = new Users()
                {
                    id = acount.id,
                    username = acount.username,
                    password = acount.password,
                    priviledgeType = acount.priviledgeType,
                    email = acount.email,
                    ip = acount.ip,
                    gold = acount.gold,
                    silver = acount.silver,
                    lastKnownIp = acount.lastKnownIp,
                    loginTime = acount.loginTime,
                    logoutTime = acount.logoutTime,
                    createTime = acount.createTime
                };
                using (ITransaction transaction = session.session.BeginTransaction())
                {
                    session.session.Merge(usr); // <-- this
                    transaction.Commit();
                }
            }
            
        }

        public void addEntity(DbEntity acc)
        {
            if (acc is CharacterOBJ)
            {
                using (ITransaction transaction = session.session.BeginTransaction())
                {
                    session.session.Save(((CharacterOBJ)acc).Get()); // <-- this
                    transaction.Commit();
                }
            }
        }
    }
}
