﻿using Assets.Database.Models;
using Assets.Scripts.Models;
using GateWayServer.Engine.Database.Models;
using JHUI.Utils;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UniversalDB.classes;

namespace LoginServer.Database
{
    public sealed class GameConfigsManager : JBehavor
    {
        private static readonly GameConfigsManager instance = new GameConfigsManager();
        public static GameConfigsManager Instance
        {
            get
            {
                return instance;
            }
        }
        private int ShipList = 0;
        private int WeaponList = 1;
        private int MapList = 2;
        private eListCollection fileDB = new eListCollection();
        private Dictionary<int, WeaponConfig> weaponConfig = new Dictionary<int, WeaponConfig>();
        private Dictionary<int, ShipConfig> shipConfig = new Dictionary<int, ShipConfig>();
        public bool isLoaded = false;
        private Dictionary<int, GameMap> gameMapConfig = new Dictionary<int, GameMap>();
        private GameConfigsManager()
        {

        }
        public GameMap getMapByID(int mapId)
        {
            if (this.gameMapConfig.ContainsKey(mapId))
                return this.gameMapConfig[mapId];
            return (GameMap)null;
        }

        public void InitDb()
        {
            /*
#if DEBUGCONFIGS
            string path = @"C:\Users\IcyTeck\Documents\Visual Studio 2015\Projects\GameDataBaseEditor\GameDataBaseEditor\bin\Debug\elements.data";
            this.fileDB.Load(path);
#else
            this.fileDB.Load(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data" + Path.DirectorySeparatorChar.ToString() + "elements.data"));
#endif

            this.weaponConfig = new Dictionary<int, WeaponConfig>();
            for (int e = 0; e < this.fileDB.Lists[this.WeaponList].elementValues.Count; ++e)
            {
                WeaponConfig weaponConfig = new WeaponConfig();
                foreach (PropertyInfo property in typeof(WeaponConfig).GetProperties())
                {
                    object valueX = this.fileDB.getValueX(this.WeaponList, e, property.Name);
                    property.SetValue((object)weaponConfig, valueX);
                }
                this.weaponConfig.Add(weaponConfig.Id, weaponConfig);
            }
            this.shipConfig = new Dictionary<int, ShipConfig>();
            for (int e = 0; e < this.fileDB.Lists[this.ShipList].elementValues.Count; ++e)
            {
                ShipConfig shipConfig = new ShipConfig();
                foreach (PropertyInfo property in typeof(ShipConfig).GetProperties())
                {
                    object valueX = this.fileDB.getValueX(this.ShipList, e, property.Name);
                    property.SetValue((object)shipConfig, valueX);
                }
                this.shipConfig.Add(shipConfig.id, shipConfig);
            }
            this.gameMapConfig = new Dictionary<int, GameMap>();
            for (int e = 0; e < this.fileDB.Lists[this.MapList].elementValues.Count; ++e)
            {
                GameMap gameMap = new GameMap();
                PropertyInfo[] properties = typeof(GameMap).GetProperties();
                for (int index = 0; index < properties.Length; ++index)
                {
                    object valueX = this.fileDB.getValueX(this.MapList, e, properties[index].Name);
                    properties[index].SetValue((object)gameMap, valueX, (object[])null);
                }
                this.gameMapConfig.Add(gameMap.id, gameMap);
            }
            */
            this.isLoaded = true;
        }

        public List<GameMap> getAllServers()
        {
            return this.gameMapConfig.Values.ToList<GameMap>();
        }

        public ShipConfig getShipModelById(int modelId)
        {
            if (this.shipConfig.ContainsKey(modelId))
                return this.shipConfig[modelId];
            return null;
        }

        public WeaponConfig getGunModelById(int modelId)
        {
            if (this.weaponConfig.ContainsKey(modelId))
                return this.weaponConfig[modelId];
            return null;
        }

        public GameMap[] getAllMaps()
        {
            return this.gameMapConfig.Values.ToArray<GameMap>();
        }
    }
}
