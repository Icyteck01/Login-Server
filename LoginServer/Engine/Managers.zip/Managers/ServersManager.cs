﻿using GateWayServer.Engine.Database.Managers;
using GateWayServer.Engine.Database.Models;
using GateWayServer.InterServerCommunication.Packets;
using JHUI.Utils;
using LoginServer.Engine.Managers;
using System.Collections.Generic;
using System.Linq;

namespace LoginServer.Database
{
    public sealed class ServersManager : JBehavor
    {
        private static readonly ServersManager instance = new ServersManager();
        public static ServersManager Instance
        {
            get
            {
                return instance;
            }
        }
        private Dictionary<int, Server> servers = new Dictionary<int, Server>();
        private List<GameServerPort> portsAvalible = new List<GameServerPort>();
        private LobyManager lobyManager = null;
        private int startPort = 21000;
        private int maxPort = 24000;
        private float pingTimeOut = 35f;

        private ServersManager()
        {
            while (startPort < maxPort)
            {
                startPort = startPort + 1;
                portsAvalible.Add(new GameServerPort()
                {
                    Port = startPort,
                    ConnectionId = 0,
                    isFree = true,
                    lastUpdateTime = 0.0
                });
            }
            lobyManager = LobyManager.Instance;
        }

        public void UpdateStatus(int connectionId, int mapId, int status)
        {
            if (lobyManager == null)
                lobyManager = LobyManager.Instance;

            if (servers.ContainsKey(connectionId))
            {
                Server server = servers[connectionId];
                server.state = (STATE)status;
                if (server.LobbyId >= 0 && server.state == STATE.STARTED_NO_REGISTER)
                {
                    Loby lobyByUid = lobyManager.getLobyByUid(server.LobbyId);
                    if (lobyByUid != null)
                    {
                        lobyManager.DelLoby(lobyByUid.id);
                        server.LobbyId = -1;
                    }
                }
            }
        }

        public void updateGS(int connectionId, HandShake egr)
        {

            if (!servers.ContainsKey(connectionId))
            {
                Server server = new Server()
                {
                    connectionId = connectionId,
                    ip = egr.ip,
                    mapId = egr.mapId,
                    port = egr.port,
                    state = (STATE)egr.status
                };
                servers[connectionId] = server;
                LogParser.Info(string.Format("ONAddSession:[{0}] SID[{1}]", connectionId, egr.mapId));
            }
            else
            {
                Server server = new Server()
                {
                    connectionId = connectionId,
                    ip = egr.ip,
                    mapId = egr.mapId,
                    port = egr.port,
                    state = (STATE)egr.status
                };
                servers[connectionId] = server;
            }
        }

        public void updateTimeStamp(int connectionId)
        {
            GameServerPort gameServerPort = portsAvalible.Find(x => x.ConnectionId == connectionId);
            if (gameServerPort == null)
                return;
            gameServerPort.lastUpdateTime = (double)Time.time + pingTimeOut;
        }

        public GameServerPort getNextFreePort(int connectionId)
        {
            GameServerPort gameServerPort1 = portsAvalible.Find(x => x.isFree);
            if (gameServerPort1 == null)
            {
                startPort = startPort + 1;
                GameServerPort gameServerPort2 = new GameServerPort();
                gameServerPort2.Port = startPort;
                gameServerPort2.ConnectionId = connectionId;
                gameServerPort2.isFree = false;
                gameServerPort2.lastUpdateTime = (double)Time.time + pingTimeOut;
                portsAvalible.Add(gameServerPort2);
                LogParser.Info(string.Format("SERVER CREATE NEW PORT SID:[{0}] PORT[{1}] - CREATED", connectionId, gameServerPort2.Port));
                return gameServerPort2;
            }
            gameServerPort1.ConnectionId = connectionId;
            gameServerPort1.isFree = false;
            gameServerPort1.lastUpdateTime = Time.time + (double)pingTimeOut;
            LogParser.Info(string.Format("SERVER CREATE NEW PORT SID:[{0}] PORT[{1}] - USED", connectionId, gameServerPort1.Port));
            return gameServerPort1;
        }

        public Server GetServerByConnectionId(int connectionId)
        {
            if (servers.ContainsKey(connectionId))
                return servers[connectionId];//            return servers.FirstOrDefault(x => x.connectionId == connectionId);
            return null;
        }

        /// <summary>
        /// Called when server disconnects
        /// </summary>
        /// <param name="connectionId"></param>
        public void removeByConnectionId(int connectionId)
        {
            if (lobyManager == null)
                lobyManager = LobyManager.Instance;

            if (servers.ContainsKey(connectionId))
            {
                
                int lobbyId = servers[connectionId].LobbyId;
                GameServerPort gameServerPort = portsAvalible.Find(x => x.ConnectionId == connectionId);
                if (gameServerPort != null)
                    gameServerPort.isFree = true;
                Loby lobyByUid = lobyManager.getLobyByUid(lobbyId);
                if (lobyByUid != null && lobyByUid.HasSentToGsInfo)
                {
                    lobyByUid.HasSentToGsInfo = false;
                    if (!lobyManager.ReAddPlayersToQueue(lobbyId))
                    {
                        lobyManager.ReAddAllPlayers(servers[connectionId].players);
                    }

                }
                servers.Remove(connectionId);
                LogParser.Info(string.Format("ONDelSession:[{0}]", connectionId));

            }
        }
        /// <summary>
        /// alll connected games servers
        /// </summary>
        /// <returns></returns>
        public List<Server> getServers()
        {
            return servers.Values.ToList();
        }

        public GameServerPort getPortByPort(int portNo, int connectionId)
        {
            GameServerPort gameServerPort1 = portsAvalible.Find(x => x.Port == portNo);
            if (gameServerPort1 == null)
            {
                GameServerPort gameServerPort2 = new GameServerPort();
                gameServerPort2.Port = portNo;
                gameServerPort2.ConnectionId = connectionId;
                gameServerPort2.lastUpdateTime = (double)Time.time + pingTimeOut;
                portsAvalible.Add(gameServerPort2);
                gameServerPort2.isFree = false;
                LogParser.Info(string.Format("SERVER REQUEST SID:[{0}] PORT[{1}] - CREATE", connectionId, portNo));
                return gameServerPort2;
            }
            gameServerPort1.isFree = false;
            gameServerPort1.Port = portNo;
            gameServerPort1.lastUpdateTime = (double)Time.time + pingTimeOut;
            gameServerPort1.ConnectionId = connectionId;
            LogParser.Info(string.Format("SERVER REQUEST SID:[{0}] PORT[{1}] - MODIFY", connectionId, portNo));
            return gameServerPort1;
        }
    }
}
