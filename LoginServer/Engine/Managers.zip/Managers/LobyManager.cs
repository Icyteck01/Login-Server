﻿using Assets.NetworkPackets.Models;
using Assets.Scripts.Network.SoketIONetwork.Communication;
using DRNetworkProtocol;
using JHUI.Utils;
using LoginServer.Database;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Assets.Scripts.Network.SoketIONetwork.Communication.Packets;

namespace LoginServer.Engine.Managers
{
    public enum LobyType
    {
        FREE_FOR_ALL,
        TEAM_GAME,
        CAPTURE_THE_FLAG
    }
    public struct AtomicInteger
    {
        private int value;
        public int Get()
        {
            return Interlocked.Increment(ref value);
        }
    }

    public class Loby
    {
        public int id = 0;
        public List<PlayerSerilize> players = new List<PlayerSerilize>();
        public int serverConnectionId = 0;
        public Loby(int id)
        {
            this.id = id;
        }
        public bool HasSentToGsInfo = true;
        internal int min;
        internal int max;
    }


    public class LobyManager : JBehavor
    {
        private static readonly LobyManager instance = new LobyManager();
        public static LobyManager Instance
        {
            get
            {
                return instance;
            }
        }
        public int minPlayersToConnect = 0;
        public int maxPlayersToConnect = 0;
        private Random rnd = new Random();
        /// <summary>
        /// USER ID, PLAYER SERIALIZED
        /// </summary>
        private Dictionary<int, PlayerSerilize> PlayerQueue = new Dictionary<int, PlayerSerilize>();
        private Dictionary<int, Loby> Queued_Lobyes = new Dictionary<int, Loby>();
        private Queue<PlayerSerilize> queue = new Queue<PlayerSerilize>();
        private AtomicInteger atomicInteger;
        private AccountManager acm;
        public LobyManager()
        {
            acm = AccountManager.Instance;
            this.InvokeRepeating(new Action(this.CheckStart), 0.1f, 0.0f);
        }

        private void CheckStart()
        {
            if(queue.Count > 0)
            {
                getPlayersForPlayer(queue.Dequeue());
            }
            else
            {
                if (PlayerQueue.Count > 0)
                {
                    var first = PlayerQueue.First();
                    int key = first.Key;
                    queue.Enqueue(PlayerQueue[key]);
                }
                    
            }
        }

        public bool AddPlayerToQueue(CharacterOBJ player, LobyType type)
        {
            if (player != null)
            {
                if (!PlayerQueue.ContainsKey(player.userId)) {
                    PlayerQueue.Add(player.userId, player.getPlayerSer());
                    PlayerQueue[player.userId].GameType = (short)type;
                    queue.Enqueue(PlayerQueue[player.userId]);
                    LogParser.Debug("Player id:" + player.userId + " Joins QUEUE");
                    return true;
                }
            }
            return false;
        }

        public bool AddPlayerToQueue(PlayerSerilize player)
        {
            if (player != null)
            {
                if (!PlayerQueue.ContainsKey(player.UserId))
                {
                    PlayerQueue.Add(player.UserId, player);
                    LogParser.Debug("Player id:" + player.UserId + "RE Joins QUEUE");
                    return true;
                }
            }
            return false;
        }

        public bool DelPlayerFromQueue(int userId)
        {
            if (PlayerQueue.ContainsKey(userId))
            {
                PlayerSerilize player = null;
                LogParser.Debug("Player id:" + userId + " Leave QUEUE");
                PlayerQueue.Remove(userId);
                return player != null;
            }
            return false;
        }

        private void getPlayersForPlayer(PlayerSerilize player)
        {
            //player.level;
            int min = player.Level - 2;
            int max = player.Level + 2;
            PlayerSerilize[] result = PlayerQueue.Values.Where(x => x.Level >= min && x.Level <= max).ToArray();
            if(result.Length >= minPlayersToConnect)
            {
                sendInfotoGS(result, min, max);
            }
        }

        private void sendInfotoGS(PlayerSerilize[] result, int min, int max)
        {
            List<PlayerSerilize> newplayers = new List<PlayerSerilize>();
            for (int i = 0; i < result.Length; i++)
            {
                AccountOBJ onlineById = this.acm.getAccountOnlineByUserId(result[i].UserId);
                if (onlineById != null && onlineById.IsInQueue)
                {
                    newplayers.Add(result[i]);
                }
                else
                {
                    DelPlayerFromQueue(result[i].UserId);
                }
            }
            if (newplayers.Count >= minPlayersToConnect)
            {
                List<Server> servers = ServersManager.Instance.getServers();
                if (servers.Count > 0)
                {
                    Server s = null;
                    int randomNo = rnd.Next(servers.Count);
                    try
                    {
                        s = servers[randomNo];
                    }
                    catch { }
                    if (s != null)
                    {
                        Loby loby = getLoby(min, max);// new Loby(atomicInteger.Get());
                        loby.min = min;
                        loby.max = max;
                        InterPayLoad payload = new InterPayLoad();
                        payload.lobyId = loby.id;
                        loby.players = newplayers;//FOR REF
                        servers[randomNo].LobbyId = loby.id;
                        Queued_Lobyes[loby.id] = loby;
                        payload.writeShips(newplayers.ToArray());
                        s.players = newplayers;
                       
                        for (int i = 0; i < s.players.Count; i++)
                        {
                            DelPlayerFromQueue(s.players[i].UserId);
                        }
                        NetworkServer.Instance.SendToClient(servers[randomNo].connectionId, NetworkConstants.GS_USERDOMAIN, payload);
                        LogParser.Debug("SENT PACKET TO GS id:" + servers[randomNo].connectionId +" Players:"+ s.players.Count + " Players_inQuueue:" + PlayerQueue.Count);
                    }
                }
            }
        }

        public Loby getLoby(int min, int max)
        {
            Loby lob = Queued_Lobyes.Values.FirstOrDefault(x => x.min == min && x.max == max);
            if (lob == null)
            {
                lob = new Loby(atomicInteger.Get());
                LogParser.Debug("Creaded Loby :"+lob.id);
                return lob;
            }
            else
            {
                LogParser.Debug("Selected Loby :" + lob.id);
                return lob;
            }
          
        }

        public Loby getLobyByUid(int lobbyId)
        {
            if (Queued_Lobyes.ContainsKey(lobbyId))
                return Queued_Lobyes[lobbyId];
            return null;
        }

        public void ReAddAllPlayers(List<PlayerSerilize> players)
        {
            for (int i = 0; i < players.Count; i++)
            {
                AccountOBJ onlineById = this.acm.getAccountOnlineByUserId(players[i].UserId);
                if (onlineById != null && onlineById.IsInQueue)
                {
                    AddPlayerToQueue(players[i]);
                }
            }
        }

        public bool ReAddPlayersToQueue(int lobbyId)
        {
            Loby loby = getLobyByUid(lobbyId);
            if (loby != null)
            {
                for (int i = 0; i < loby.players.Count; i++)
                {
                    AccountOBJ onlineById = this.acm.getAccountOnlineByUserId(loby.players[i].UserId);
                    if (onlineById != null && onlineById.IsInQueue)
                    {
                        AddPlayerToQueue(loby.players[i]);
                    }
                }
                bool deleted = DelLoby(lobbyId);
                if (deleted)
                {
                    LogParser.Debug("LOBY DELETED id:" + lobbyId);
                    return true;
                }
                else
                    LogParser.Debug("FAIL TO DELETE LOBY id:" + lobbyId);
                return false;
            }
            else
            {
                return false;
            }
        }

        public bool DelLoby(int id)
        {
            if (Queued_Lobyes.ContainsKey(id))
            {
                Queued_Lobyes.Remove(id);
                return true;
            }
            return false;
        }

        public void ConectPlayers(int[] confirmed, int state, int lobyId, int conId)
        {
            Loby loby = getLobyByUid(lobyId);
            if(loby != null)
            {
                if (loby.players.Count > 0)
                {
                    loby.players.RemoveAll(x => confirmed.Contains(x.UserId));
                }
                if(loby.players.Count == 0)
                {
                    LogParser.Debug("GS acknowledged Loby id:"+ lobyId + ".");
                    GS_SET_SERVER connectPacket = new GS_SET_SERVER();
                    Server server = ServersManager.Instance.GetServerByConnectionId(conId);
                    if(server != null)
                    {
                        connectPacket.ip = server.ip;
                        connectPacket.status = 0;
                        connectPacket.portNo = server.port;
                        connectPacket.gsState = (short)server.state;
                        List<int> cons = new List<int>();
                        for(int i = 0; i < confirmed.Length; i++)
                        {
                            AccountOBJ onlineById = this.acm.getAccountOnlineByUserId(confirmed[i]);
                            if (onlineById != null && onlineById.IsInQueue)
                            {
                                cons.Add(onlineById.connectionID);
                            }
                        }
                        NetworkServer.Instance.SendToClients(cons.ToArray(), NetworkConstants.CMD_DISPLAY_COUNTDOWN, connectPacket);
                    }
                    else
                    {
                        //SERVER IS NULL PUT PLAYERS BACK TO QUEUE
                    }
                    
                }
            }
            else
            {
                NetworkServer.Instance.SendToClient(conId, NetworkConstants.DE_USERDOMAIN, new ONE_CODE_PACKET(0));
            }
        }
    }
}
